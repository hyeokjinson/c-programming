#include "main.h"


void SortClient(__client **person, int *m){
	int i,j;
	__client *temp;
	
	
	for(i=0;i<*m;i++){
		for(j=0;j<*m-i-1;j++){
			if(strcmp(person[j]->num,person[j+1]->num)>0){
				temp=person[j];
				person[j]=person[j+1];
				person[j+1]=temp;
			}
		}
	}
}
