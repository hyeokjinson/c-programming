#include "main.h"


void FreeClient(__client **person, int *m){
	int i;
	
	
	for(i=0;i<*m;i++){
		free(person[i]);
	}
	
	
	//free(person);
}
