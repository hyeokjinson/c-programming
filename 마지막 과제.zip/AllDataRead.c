#include "main.h"


void AllDataRead(__client **person, int *m){
	int i, t;
	
	FILE *fp;
	fp=fopen("client.txt", "rb");
	if(fp==NULL){
		printf("'client.txt'�� ������ �ʾҽ��ϴ�.\n");
		exit -1;
	}
	
	
	//if(feof(fp)==0)
	fread(&t, sizeof(int), 1, fp);
		
	*m=t;	
		
		
	for(i=0;i<*m;i++){
		person[i]=(__client *)malloc(sizeof(__client));
		
		
		fread(person[i], sizeof(__client), 1, fp);
	}
	
	
	fclose(fp);
}
