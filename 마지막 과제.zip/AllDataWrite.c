#include "main.h"


void AllDataWrite(__client **person, int *m){
	int i;
	int t;
	
	
	FILE *fp;
	fp=fopen("client.txt", "wb");
	
	
	t=*m;
	fwrite(&t, sizeof(int), 1, fp);
	
	SortClient(person, m);
	for(i=0;i<*m;i++){
		fwrite(person[i], sizeof(__client), 1 , fp);
	}
	
	
	fclose(fp);
}
