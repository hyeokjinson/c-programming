#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "windows.h"


typedef struct client{
	char num[10];
	char pass[20];
	char name[20];
	char address[25];
	char phone[20];
}__client;


void menu(__client **, int *);
void PrintClient(__client **, int *);
void RegClient(__client **, int *);
void copen(__client **, int *);
void Cwrt(__client **, int *);
void DeleteClient(__client **, int *);
void ModifyClient(__client **, int *);
void SearchClient(__client **, int *);
void SortClient(__client **, int *);
void FreeClient(__client **, int *);
void AllDataWrite(__client **, int *);
void AllDataRead(__client **, int *);
