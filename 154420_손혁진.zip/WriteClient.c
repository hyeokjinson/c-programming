#include "main.h"


void Cwrt(__client **person, int *m){
	FILE *fp;
	fp = fopen("client.txt", "w");
	if(fp==NULL){
		printf("'client.txt'�� ������ �ʾҽ��ϴ�.");
		exit -1;
	}
	int i;
	int k;
	
	
	k=*m;
	fwrite(&k, sizeof(int), 1, fp);
	SortClient(person, m);
	
	
	for(i=0;i<*m;i++){
		fprintf(fp, "%s\n%s\n%s\n%s\n%s\n", person[i]->num, person[i]->pass, person[i]->name, person[i]->address, person[i]->phone);
	}
	
	
	fclose(fp);
}
