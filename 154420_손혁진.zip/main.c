#include "main.h"
#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	int member=0;
	//int default_size=5;
	//int *size = &default_size;
	int *m = &member;
	//int count;
	__client *person[100];
	/*__client **person;
	person = (__client **)malloc(sizeof(__client *));
	if(person==NULL){
		printf("���� �Ҵ翡 �����Ͽ����ϴ�.\n");
		return -1;
	}
	*/
	
	
	copen(person, m);
	menu(person, m);
	
	
	return 0;
}
