#include "main.h"


void copen(__client **person, int *m){
	FILE *fp;
	fp = fopen("client.txt", "r");
	if(fp==NULL){
		printf("'client.txt'�� ������ �ʾҽ��ϴ�.\n");
		exit -1;
	}
	int k=0;
	int default_size=10;
	int i,t;


	if(feof(fp)==0)
		fread(&k, sizeof(int), 1, fp);
	
	
	for(i=0;i<k;i++){
		//person[i]=(__client *)malloc(sizeof(__client));
		__client *p=(__client *)malloc(sizeof(__client));
		/*
		fgets(person[i]->num, 10, fp);
		person[i]->num[strlen(person[i]->num)-1]='\0';
		printf("%s\n", person[i]->num);
		fgets(person[i]->pass, 20, fp);
		person[i]->pass[strlen(person[i]->pass)-1]='\0';
		printf("%s\n", person[i]->pass);
		fgets(person[i]->name, 20, fp);
		person[i]->name[strlen(person[i]->name)-1]='\0';
		printf("%s\n", person[i]->name);
		fgets(person[i]->address, 25, fp);
		person[i]->address[strlen(person[i]->address)-1]='\0';
		printf("%s\n", person[i]->address);
		fgets(person[i]->phone, 20, fp);
		person[i]->phone[strlen(person[i]->phone)-1]='\0';
		printf("%s\n", person[i]->phone);
		*/
		
		fgets(p->num, 10, fp);
		p->num[strlen(p->num)-1]=0;
		
		fgets(p->pass, 20, fp);
		p->pass[strlen(p->pass)-1]=0;
		
		fgets(p->name, 20, fp);
		p->name[strlen(p->name)-1]=0;
		
		fgets(p->address, 25, fp);
		p->address[strlen(p->address)-1]=0;
	
		fgets(p->phone, 20, fp);
		p->phone[strlen(p->phone)-1]=0;
	
		
	
		person[i]=p;
		/*
		if(*m==0){
			person[i]=p;
		}
	
		//	*size=*size+*size;
		
		else{
			realloc(person, sizeof(__client *)*(*m+1));
			person[*m]=p;
		}
		*/

		*m=*m+1;	
	}
	
	
	fclose(fp);
}
